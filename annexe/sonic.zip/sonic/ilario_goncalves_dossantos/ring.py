import drawsvg as draw

d = draw.Drawing(64, 64, origin='center')


d.append(draw.Circle(
    0, 0, 24,          
    fill='none',        
    stroke='#572808',   
    stroke_width=10     
))


d.append(draw.Circle(
    0, 0, 24,
    fill='none',
    stroke='#ffce00',   
    stroke_width=6      
))


d.save_png('assets/ring.png')