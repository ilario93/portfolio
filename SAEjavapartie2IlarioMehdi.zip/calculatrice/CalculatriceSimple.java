public class CalculatriceSimple {
	public static void main(String[] args){
	
	Nombre six = new Nombre(6);
	
	System.out.println(six);
	
	Nombre dix = new Nombre(10);
	
	
	
	Operation a = new Addition(dix,six);
	
	System.out.println(a+"="+a.valeur());
	
	
	
	Operation m = new Multiplication(dix,six);

	System.out.println(m+"="+m.valeur());
	
	
	
	Operation s = new Soustraction(dix,six);

	System.out.println(s+"="+s.valeur());
	
	
	
	Operation d = new Division(dix,six);

	System.out.println(d+"="+d.valeur());
	
	
	
	Nombre zero = new Nombre(0);
	
	Operation d1 = new Division(dix,zero);
	
		try {
		System.out.println(d1+"="+d1.valeur());

		} 
		catch ( ArithmeticException e){
			System.out.println("ne peut pas diviser par zero");
		}
		
		System.out.println(" " );
		System.out.println("PARTIE 2");
		
		
	Expression douze = new Nombre(12);
	
	Expression neuf = new Nombre(9);
	
	Expression  dixHuit = new Nombre(18);
	
	
	
	Expression A1 = new Addition(neuf, douze);
	
	System.out.println(A1+"="+A1.valeur());
	
	Expression S1 = new Soustraction(dixHuit, douze);
	
	System.out.println(S1+"="+S1.valeur());
	
	Expression M1 = new Multiplication(A1, S1);
	
	System.out.println(M1+"="+M1.valeur());
	
	Expression D1 = new Division(A1, S1);
	
	System.out.println(D1+"="+D1.valeur());
	
	System.out.println("Partie 3");
	
	System.out.println(fabriqueExpression("3"));
	System.out.println(fabriqueExpression("17-2"));
	System.out.println(fabriqueExpression("(17-2)/3"));
	

	
	
	}
	
		public static Expression fabriqueExpression(String e){
		var str =e.split("");
		var number="";
		Expression expr=new Nombre(0);
		var opperande="";
		for(var letter:str) {
		
			for(int j=0;j<10;j++) {		
			if(letter.equals(String.valueOf(j))) {
				number+=letter;
			}
			if(letter.equals("-")||
			letter.equals("+")||
			letter.equals("/")||
			letter.equals("*")){
				if(opperande.equals("+")) {
						expr=new Addition(expr,new Nombre(Integer.valueOf(number)));
					}
				if(opperande.equals("-")) {
					expr=new Soustraction(expr,new Nombre(Integer.valueOf(number)));
				}
				if(opperande.equals("*")) {
					expr=new Multiplication(expr,new Nombre(Integer.valueOf(number)));
				}
				if(opperande.equals("/")) {
					expr=new Division(expr,new Nombre(Integer.valueOf(number)));
				}
				if(opperande.equals("")) {
					expr=new Nombre(Integer.valueOf(number));
				}
				opperande=letter;
				number="";
				break;
				}
			}
		
		}
		if(opperande.equals("")){
				expr=new Nombre(Integer.valueOf(number));
			}
			if(opperande.equals("-")) {
					expr=new Soustraction(expr,new Nombre(Integer.valueOf(number)));
				}
				if(opperande.equals("*")) {
					expr=new Multiplication(expr,new Nombre(Integer.valueOf(number)));
				}
				if(opperande.equals("/")) {
					expr=new Division(expr,new Nombre(Integer.valueOf(number)));
				}
				if(opperande.equals("")) {
					expr=new Nombre(Integer.valueOf(number));
				}
		
		return expr;
	}
}


