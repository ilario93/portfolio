public class Soustraction extends Operation{
	
	public Soustraction( Expression nb1, Expression nb2){
	
		super(nb1,nb2);
		
		}
	public double valeur(){
		return op1.valeur()-op2.valeur();
		}
	public String toString(){
		return "(" + op1.valeur() +"-"+ op2.valeur() +")";
		}
	}
		
		
