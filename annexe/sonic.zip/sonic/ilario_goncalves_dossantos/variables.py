import pygame 

screen = pygame.display.set_mode((800, 400))


largeur = 80


sonic_run = pygame.image.load("assets/sonicrun.png").convert_alpha()
sonic_run1 = pygame.image.load("assets/sonicrun1.png").convert_alpha()
sonic_run2 = pygame.image.load("assets/sonicrun2.png").convert_alpha()
sonic_run3 = pygame.image.load("assets/sonicrun3.png").convert_alpha()
sonic_run4 = pygame.image.load("assets/sonicrun4.png").convert_alpha()
sonic_yellow = pygame.image.load("assets/sonic_yellow1.png")
sonic_yellow_run = pygame.image.load("assets/sonicsuper.png")
emerald = pygame.image.load("assets/chaos_emerald.png").convert_alpha()
sonic_jump = pygame.image.load("assets/sonicjump.png").convert_alpha()
sonic_stop = pygame.image.load("assets/sonic2.png").convert_alpha()
aura_img = pygame.image.load("assets/aura1.png").convert_alpha()
map_bg = pygame.image.load("assets/GreenHillTileSet.png").convert_alpha()
background = pygame.image.load("assets/images.png").convert_alpha()
sonic_skid = pygame.image.load("assets/sonicSkid.png").convert_alpha()
sonic_rouler = pygame.image.load("assets/spin1.png").convert_alpha()    
sonic_rouler1 = pygame.image.load("assets/spin2.png").convert_alpha()
sonic_rouler2 = pygame.image.load("assets/spin3.png").convert_alpha()
sonic_rouler3 = pygame.image.load("assets/spin5.png").convert_alpha()
sonic_rouler4 = pygame.image.load("assets/spin4.png").convert_alpha()
ring = pygame.image.load("assets/ring.png").convert_alpha()
mort = pygame.image.load("assets/docteur.png").convert_alpha()
gagner = pygame.image.load("assets/Sonic-Logo.png").convert_alpha()
sonic_bas = pygame.image.load("assets/sonicdown.png").convert_alpha()
sonic_transform = pygame.image.load("assets/transfo.png").convert_alpha()
sonic_transform1 = pygame.image.load("assets/transfo1.png").convert_alpha()
sonic_transform2 = pygame.image.load("assets/transfo2.png").convert_alpha()
sonic_transform3 = pygame.image.load("assets/transfo3.png").convert_alpha()
sonic_transform4 = pygame.image.load("assets/transfo4.png").convert_alpha()
sonic_transform5 = pygame.image.load("assets/transfo5.png").convert_alpha()
sonic_transform6 = pygame.image.load("assets/transfo6.png").convert_alpha()
sonic_transform7 = pygame.image.load("assets/transfo7.png").convert_alpha() 
sonic_transform8 = pygame.image.load("assets/transfo8.png").convert_alpha()
sonic_transform9 = pygame.image.load("assets/transfo9.png").convert_alpha()
sonic_transform10 = pygame.image.load("assets/transfo10.png").convert_alpha()

sonic_run_droit = pygame.transform.scale(sonic_run, (int(632*largeur/738), 64))
sonic_yellow_droit = pygame.transform.scale(sonic_yellow, (84, 84))
sonic_yellow_gauche = pygame.transform.flip(sonic_yellow_droit, True, False)
sonic_yellow_run_gauche = pygame.transform.scale(sonic_yellow_run, (150, 150))
sonic_yellow_run_droit = pygame.transform.flip(sonic_yellow_run_gauche, True, False)
sonic_yellow_flying = pygame.transform.rotate(sonic_yellow_run, -90)
sonic_yellow_flying_gauche = pygame.transform.scale(sonic_yellow_flying, (129, 129))
sonic_yellow_flying = pygame.transform.flip(sonic_yellow_flying_gauche, True, False)
emerald_img = pygame.transform.scale(emerald, (40, 40))
sonic_jump = pygame.transform.scale(sonic_jump, (80, 84))
sonic_stop_droit = pygame.transform.scale(sonic_stop, (84, 84))
sonic_stop_gauche = pygame.transform.flip(sonic_stop_droit, True, False)
rect_plateforme = pygame.Rect(68, 51, 50, 33)
image_plateforme = map_bg.subsurface(rect_plateforme)
sol = pygame.transform.scale(image_plateforme, (150, 60))
background = pygame.transform.scale(background, (background.get_width(), 400))
ring = pygame.transform.scale(ring, (40, 40))
aura_img_gauche = pygame.transform.flip(aura_img, True, False)
mort = pygame.transform.scale(mort, (400, 200))
gagner = pygame.transform.scale(gagner, (400, 200))
sonic_bas = pygame.transform.scale(sonic_bas, (130, 130))
sonic_bas_gauche = pygame.transform.flip(sonic_bas, True, False)

run_right_frames = [
    pygame.transform.scale(sonic_run, (int(632*largeur/738), 64)),
    pygame.transform.scale(sonic_run1, (int(632*largeur/738), 64)),
    pygame.transform.scale(sonic_run2, (int(632*largeur/738), 64)),
    pygame.transform.scale(sonic_run3, (int(632*largeur/738), 64)),
    pygame.transform.scale(sonic_run4, (int(632*largeur/738), 64)),
]

run_left_frames = [pygame.transform.flip(img, True, False) for img in run_right_frames]
sonic_arret = pygame.transform.scale(sonic_skid, (int(901*largeur/738), 64))
sonic_arret_gauche = pygame.transform.flip(sonic_arret, True, False)

rouler_droit = [
    pygame.transform.scale(sonic_rouler, (84, 84))
,
    pygame.transform.scale(sonic_rouler1, (84, 84)),
    pygame.transform.scale(sonic_rouler2, (84, 84)),
    pygame.transform.scale(sonic_rouler3, (84, 84)),
    pygame.transform.scale(sonic_rouler4, (84, 84)),
]

rouler_gauche = [pygame.transform.flip(img, True, False) for img in rouler_droit]

tranfo_styler = [
    pygame.transform.scale(sonic_transform, (84, 84)),
    pygame.transform.scale(sonic_transform1, (84, 84)),
    pygame.transform.scale(sonic_transform2, (84, 84)),
    pygame.transform.scale(sonic_transform3, (84, 84)),
    pygame.transform.scale(sonic_transform4, (84, 84)),
    pygame.transform.scale(sonic_transform5, (84, 84)),
    pygame.transform.scale(sonic_transform6, (84, 84)),
    pygame.transform.scale(sonic_transform7, (84, 84)),
    pygame.transform.scale(sonic_transform8, (84, 84)),
    pygame.transform.scale(sonic_transform9, (84, 84)),
    pygame.transform.scale(sonic_transform10, (84, 84)),
]
