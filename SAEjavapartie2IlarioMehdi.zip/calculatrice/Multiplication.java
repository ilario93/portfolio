public class Multiplication extends Operation{
	
	public Multiplication( Expression nb1, Expression nb2){
	
		super(nb1,nb2);
		
		}
	public double valeur(){
		return op1.valeur()*op2.valeur();
		}
	public String toString(){
		return "(" + op1.valeur() +"x"+ op2.valeur() +")";
		}
	}
		
		
