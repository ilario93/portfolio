import pygame
import math
import random
import variables as var



gravity = 1
jump_speed = -15
max_vitesse = 8 
acceleration = 0.1
deceleration = 0.3
skid_duration = 15
spin_anim_speed = 20
spin_min_speed = 2
transform_anim_speed = 10
platforme = 350
sol_debut = 0
largeur_sol = 100
sol_fin = sol_debut + 20 * largeur_sol

emerald_positions = [(200, platforme - 40), (400, platforme - 40), (600, platforme - 40)]
emeralds = [pygame.Rect(x, y, 20, 20) for x, y in emerald_positions]

rings = []
for i in range(10):
    pos_x = random.randint(400, 3000)
    
    pos_y = random.randint(50, 300)
    rect_ring=pygame.Rect(pos_x, pos_y, 20, 20)
    rings.append(rect_ring)


class Sonic:
    def __init__(self):

        self.rect = var.sonic_run_droit.get_rect()
        self.rect.topleft = (50, 300)
        self.saut = False
        self.y_vitesse = 0    
        self.camera = 0
        self.accroupi = False
        self.last_direction = 1
        self.aura_angle = 0
        self.super_sonic = False
        self.aura_vitesse = 9
        self.run_frame_index = 0
        self.run_frame_timer = 0
        self.vitesse=0

        self.glisser= False
        self.skid_timer = 0

        self.spin_frame_index = 0
        self.spin_timer = 0
       
        self.transforming = False
        self.transform_frame_index = 0
        self.transform_timer = 0

    def mouvement(self,keys, sol_debut, sol_fin):
           
        if keys[pygame.K_RIGHT]:
            self.vitesse = min(self.vitesse + acceleration, max_vitesse)
            self.rect.x += self.vitesse
            self.last_direction = 1
            self.glisser = False

        elif keys[pygame.K_LEFT]:
            self.vitesse = min(self.vitesse + acceleration, max_vitesse)
            self.rect.x -= self.vitesse
            self.last_direction = -1
            self.glisser = False
        else:
            if self.vitesse > 0 and not self.super_sonic:
                self.glisser = True
                self.skid_timer = skid_duration

            if self.glisser:
                if self.last_direction == 1:
                    self.rect.x += self.vitesse
                else:
                    self.rect.x -= self.vitesse

                self.vitesse = max(self.vitesse - deceleration, 0)
                self.skid_timer -= 1
                if self.skid_timer <= 0 or self.vitesse == 0:
                    self.glisser = False
                    self.vitesse = 0
        in_ground_zone = sol_debut <= self.rect.centerx <= sol_fin
        on_ground = in_ground_zone and (self.rect.bottom >= platforme)
        return in_ground_zone, on_ground
    
    def haut_bas(self, keys, in_ground_zone, on_ground):
        if self.super_sonic:
            self.saut = False 
            self.accroupi = False    
            if keys[pygame.K_SPACE]:
                self.rect.y -= 5
            if keys[pygame.K_DOWN]:
                self.rect.y += 5
            if self.rect.bottom > platforme:
                self.rect.bottom = platforme
        else:
            if not self.saut and keys[pygame.K_SPACE]:
                self.saut = True
                self.y_vitesse = jump_speed
        if keys[pygame.K_DOWN]  and on_ground and not self.saut:
            self.accroupi = True
        else:
            self.accroupi = False
            self.spin_frame_index = 0
            self.spin_timer = 0
            self.spin_anim_speed = 10
        if self.accroupi:
            self.spin_timer += 1

        if self.spin_timer >= self.spin_anim_speed:
            self.spin_timer = 0
            self.spin_frame_index = (self.spin_frame_index + 1) % len(var.rouler_droit)
            self.spin_anim_speed = max(spin_min_speed, self.spin_anim_speed - 1)
    
        if not self.super_sonic:
            self.saut
            self.rect.y += self.y_vitesse
            self.y_vitesse += gravity
            if in_ground_zone and self.rect.bottom >= platforme:
                self.rect.bottom = platforme
                if self.y_vitesse > 0:
                    self.y_vitesse = 0
                    self.saut = False
        else:
            self.y_vitesse = 0


         
    def tomber_apres_fin_platforme(self, in_ground_zone, on_ground):
        if in_ground_zone and self.rect.bottom > platforme:
            self.rect.bottom = platforme
            self.y_vitesse = 0
            on_ground = True
            self.saut = False

        

    def transformation(self):
         
        if len(emeralds) == 0 and not self.super_sonic and not self.transforming:
            self.transforming = True
            self.transform_frame_index = 0
            self.transform_timer = 0
            self.vitesse = 0
            self.y_vitesse = 0
        if self.transforming:
            self.transform_timer += 1

            if self.transform_timer >= transform_anim_speed:
                self.transform_timer = 0
                self.transform_frame_index += 1
            if self.transform_frame_index >= len(var.tranfo_styler):
                self.transforming = False
                self.super_sonic = True
                self.transform_frame_index = len(var.tranfo_styler) - 1


    def image_sonic(self, keys):
        if self.transforming:
            image_actuel = var.tranfo_styler[self.transform_frame_index]
        elif self.saut:
            image_actuel = var.sonic_jump  
        elif self.glisser:
            if self.last_direction == 1:
                image_actuel = var.sonic_arret
            else:
                image_actuel = var.sonic_arret_gauche
        elif self.super_sonic:
            if keys[pygame.K_SPACE]:
                if self.last_direction == -1:
                    image_actuel = var.sonic_yellow_flying_gauche
                else:
                    image_actuel = var.sonic_yellow_flying
            elif keys[pygame.K_RIGHT]:
                image_actuel = var.sonic_yellow_run_droit
            elif keys[pygame.K_LEFT]:
                image_actuel = var.sonic_yellow_run_gauche
            elif keys[pygame.K_DOWN]:
                if self.last_direction == -1:
                    image_actuel = var.sonic_bas_gauche
                else:
                    image_actuel = var.sonic_bas

            else:
                if self.last_direction == -1:
                    image_actuel = var.sonic_yellow_gauche
                else:
                    image_actuel = var.sonic_yellow_droit
                
        elif self.accroupi:
            if self.last_direction == -1:
                image_actuel = var.rouler_gauche[self.spin_frame_index]
            else:
                image_actuel = var.rouler_droit[self.spin_frame_index]
        elif keys[pygame.K_RIGHT]:
            image_actuel = var.run_right_frames[self.run_frame_index]
        elif keys[pygame.K_LEFT]:
            image_actuel = var.run_left_frames[self.run_frame_index]
        else:
            if self.last_direction == -1:
                image_actuel = var.sonic_stop_gauche
            else:
                image_actuel = var.sonic_stop_droit
        return image_actuel
    def ramasser(self, emeralds, rings):
        for i in emeralds[:]:  
            if self.rect.colliderect(i):
                emeralds.remove(i)
        for i in rings[:]: 
            if self.rect.colliderect(i):
                rings.remove(i)
    def animation_course(self, keys):
        run_anim_speed = 10 if self.vitesse < 2 else 7 if self.vitesse < 4 else 5 if self.vitesse < 6 else 0
        moving = keys[pygame.K_LEFT] or keys[pygame.K_RIGHT]

        if moving and not self.saut and not self.accroupi:
            self.run_frame_timer += 1
            if self.run_frame_timer >= run_anim_speed:
             self.run_frame_timer = 0
             self.run_frame_index = (self.run_frame_index + 1) % len(var.run_right_frames)
        else :
            self.run_frame_index = 0
            self.run_frame_timer = 0

    def draw(self, image_actuel):
        old_bottom = self.rect.bottom
        old_centerx = self.rect.centerx
        self.rect = image_actuel.get_rect()
        self.rect.bottom = old_bottom
        self.rect.centerx = old_centerx
        var.screen.blit(image_actuel,(self.rect.x - self.camera, self.rect.y))

    def aura(self):
        if self.super_sonic:
            self.aura_angle += self.aura_vitesse
            pulse = math.sin(math.radians(self.aura_angle))
            aura_size = 150+ int(pulse * 20)  
            current_aura = var.aura_img_gauche if self.last_direction == -1 else var.aura_img
            aura_scaled = pygame.transform.scale(current_aura, (aura_size, aura_size))
            aura_rect = aura_scaled.get_rect(center=self.rect.center)
            var.screen.blit( aura_scaled, (aura_rect.x - self.camera, aura_rect.y))

    def mouvement_camera(self):
        screen_center_x = 800 // 2
        if self.rect.centerx > screen_center_x:
            self.camera = self.rect.centerx - screen_center_x

    
    def map(self):
        bg_width = var.background.get_width()
        bg_x = self.camera * 0.4
        for i in range(-1, 10):
            var.screen.blit(var.background, (i * bg_width - (bg_x % bg_width), 0))
        for i in range(20):
            var.screen.blit(var.sol, (i * largeur_sol - self.camera, platforme))

    def emerald_et_rings(self):
        for i in emeralds:
            var.screen.blit(var.emerald_img, (i.x - self.camera, i.y))
        for i in rings:
            var.screen.blit(var.ring, (i.x - self.camera, i.y))
