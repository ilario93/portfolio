public abstract class Operation extends Expression {
	protected Expression op1;
	protected Expression op2;
	
	public Operation ( Expression nb1, Expression nb2){
		this.op1= nb1;
		this.op2 = nb2;
		}
		
	public abstract double valeur();
	
	public Expression getOperande1(){
		
		return this.op1;
		
		}
	
	public Expression getOperande2(){
		
		return this.op2;
		
		}
	}
