import drawsvg as draw

d = draw.Drawing(84, 84, origin='center')

d.append(draw.Lines(
    -16, -22,  
    16, -22,   
    30, -6,    
    0, 28,    
    -30, -6,   
    close=True,
    fill='#00FF00',   
    stroke='#004000', 
    stroke_width=2
))

d.save_png('assets/chaos_emerald.png')
