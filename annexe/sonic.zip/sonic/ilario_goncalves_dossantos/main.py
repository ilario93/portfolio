import pygame
import sys
import math
import random
import variables as var
import Sonic

pygame.init()
pygame.display.set_caption("Sonic après la faillit de SEGA")
clock = pygame.time.Clock()

run = True
def Evenement():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
def mourir():
    var.screen.fill((0, 0, 0))  
    rect = var.mort.get_rect(center=(800//2, 400//2))
    var.screen.blit(var.mort, rect)
    pygame.display.update()
    pygame.time.delay(2000)
    pygame.quit()
    sys.exit()
def victoire ():
    var.screen.fill((0, 0, 0))
    rect = var.gagner.get_rect(center=(800//2, 400//2))
    var.screen.blit(var.gagner, rect)
    pygame.display.update()
    pygame.time.delay(2000)
    pygame.quit()
    sys.exit()
    
sonic = Sonic.Sonic()

def game_init():
    in_ground_zone, on_ground = sonic.mouvement(keys, Sonic.sol_debut, Sonic.sol_fin)
    sonic.haut_bas(keys, in_ground_zone, on_ground)
    sonic.tomber_apres_fin_platforme(in_ground_zone, on_ground)
    sonic.ramasser(Sonic.emeralds, Sonic.rings)
    sonic.animation_course(keys)
    sonic.transformation()
    sonic.mouvement_camera()
    if sonic.rect.top > 500: 
     mourir()
    if len(Sonic.rings) == 0 :
        victoire()


def game_image():
    image_actuel = sonic.image_sonic(keys)
    sonic.map()
    sonic.emerald_et_rings()
    sonic.aura()
    sonic.draw(image_actuel)



if __name__ == "__main__":
    while run:
        clock.tick(60)  
        Evenement()
        keys = pygame.key.get_pressed()
        game_init()
        game_image()
        pygame.display.update()

pygame.quit()
sys.exit()
