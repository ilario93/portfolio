public class Division extends Operation{
	
	public Division( Expression nb1, Expression nb2){
	
		super(nb1,nb2);
		
		}
	public double valeur(){
	if (op2.valeur() == 0) {
            throw new ArithmeticException("DIvision par 0 changer ");
            }
		return op1.valeur()/op2.valeur();
		}
	public String toString(){
		return "(" + op1.valeur() +"/"+ op2.valeur() +")";
		}
	}
